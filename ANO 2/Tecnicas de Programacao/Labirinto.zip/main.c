// RA Nome
// RA Nome
// RA Nome

#include <stdio.h>
#include <stdlib.h>
#include <math.h>  /* para usar o INFINITY */
#include "grafo.h"

void ExibirGrafo (Grafo g)
{
    int i, j;
    system("CLS");
    printf ("Numero de vertices do %s: %i\n", g.digrafo==0?"GRAFO":"DIGRAFO",g.nVertices);

    // primeira linha com nomes dos v�rtices
    printf("    ");
    for (i=0; i <g.nVertices; i++)
        printf("%c   ", 65+i);
    printf("%\n");

    for (i=0; i <g.nVertices; i++)
    {
        // primeira coluna com nomes dos v�rtices
        printf("%c   ", 65+i);
        for (j=0; j < g.nVertices; j++)
            printf ("%0.0f   ", PesoDaAresta (g, i, j));
        printf ("\n");
    }
    printf ("\n");
}


int main ()
{
    int n, dig, i;
    Grafo g;
    ListaDeVertices caminho;

	/* ********************************************** 
	           crie seu labirinto aqui 
    ********************************************** */
    n = ?;
    dig = ?;
    int origem = ?;
    int destino = ?;
    CriarGrafo (&g, n, dig);
    InserirAresta (&g, , , 1);

	
	
	/* ********************************************** 
	           crie seu labirinto aqui 
    ********************************************** */

    ExibirGrafo (g);

    printf ("Busca em profundidade: \n");
    DFS(g, origem, destino, &caminho);
    for (i=0; i < caminho.nVertices-1; i++)
        printf("%c -> ",caminho.vertices[i]+65);
    printf ("%c\n\n",caminho.vertices[i]+65);


    return 0;
}
